package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class SoapRequest {

	@Test
	public void XMlValidation() throws IOException {
		
		
		String userdirectory =  System.getProperty("user.dir");
		String filepath =userdirectory +"/src/test/resources/Calcu.xml";
		
		System.out.println(filepath);
		File file = new File(filepath);
		
		if(file.exists()) {
			System.out.println("---> File Exist");
		}
		FileInputStream  fis = new FileInputStream(file);
		String requestbody =  IOUtils.toString(fis, "UTF-8");
		
		
		RestAssured.baseURI = "http://www.dneonline.com";   
		
		Response response= 	RestAssured.given().contentType("text/xml")
		.accept(ContentType.XML)
		.body(requestbody).when().log().all()
		.post("/calculator.asmx");
	

		ResponseSpecification resp =RestAssured.expect().statusCode(200);
		
			
		
		String xmlresponse = response.asString();
		
		XmlPath xml = new XmlPath(xmlresponse);
		System.out.println("PRINT VALUE");
	     System.out.println(xml.getString("AddResult"));	
		
		String fileoutpath = System.getProperty("user.dir") + "/src/test/resources/Output.xml";
		
		
		 FileOutputStream output = new FileOutputStream(fileoutpath);

     // The getBytes() method used
     // converts a string into bytes array.
		 	byte[] array = xmlresponse.getBytes();

		 	output.write(array);

		 	output.close();
		
	   	
	
		
		
	} 

	
}
