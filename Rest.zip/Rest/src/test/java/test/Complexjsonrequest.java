package test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Complexjsonrequest {
	
	@Test
	public void testwithoutpojoclass() {
		
		Map<String,Object> finalpayload = new LinkedHashMap<String,Object>();
		finalpayload.put("id", 001);
		finalpayload.put("type","donut");
		finalpayload.put("name","Cake");
		finalpayload.put("ppu",0.55);
		
		
	Map<String,Object> batters = new LinkedHashMap<String,Object>();
		
		List<Map<String,Object>> batterlist = new ArrayList<Map<String,Object>>();
		
		Map<String,Object> batter = new LinkedHashMap<String,Object>();
		batter.put("id", "1001");
		batter.put("type", "Regular");
		
		Map<String,Object> batter1 = new LinkedHashMap<String,Object>();
		batter1.put("id", "1002");
		batter1.put("type", "Chocolate");
		
		Map<String,Object> batter2 = new LinkedHashMap<String,Object>();
		batter2.put("id", "1003");
		batter2.put("type", "Blueberry");
		
		Map<String,Object> batter3 = new LinkedHashMap<String,Object>();
		batter3.put("id", "1004");
		batter3.put("type", "Devil's Food");
		
		batterlist.add(batter);
		batterlist.add(batter1);
		batterlist.add(batter2);
		batterlist.add(batter3);
		
		
		batters.put("batter", batterlist);
		
		finalpayload.put("batters", batters);
		
		
		Map<String,Object> topping = new LinkedHashMap<>();
		topping.put("id","5001");
		topping.put("type", "None");
		
		Map<String,Object> topping1 = new LinkedHashMap<>();
		topping1.put("id","5002");
		topping1.put("type", "Glazed");
		
		
		Map<String,Object> topping2 = new LinkedHashMap<>();
		topping2.put("id","5003");
		topping2.put("type", "Chocolate");
		
		Map<String,Object> topping3 = new LinkedHashMap<>();
		topping3.put("id","5004");
		topping3.put("type", "Maple");
		
		
		Map<String,Object> topping4 = new LinkedHashMap<>();
		topping4.put("id","5005");
		topping4.put("type", "Sugar");
		
		
		
		List<Object> toppingarray = new ArrayList<>();
		toppingarray.add(topping);
		toppingarray.add(topping1);
		toppingarray.add(topping2);
		toppingarray.add(topping3);		
		toppingarray.add(topping4);
		
		
		finalpayload.put("topping", toppingarray);
		
		
		RestAssured.given().log().all().body(finalpayload).post();
		
		
		
	}

}
