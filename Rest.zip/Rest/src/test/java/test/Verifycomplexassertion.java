package test;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Verifycomplexassertion {
	
	RequestSpecification httprequest;
	ResponseSpecification res;
	Response response;

	@BeforeClass
	public void setup() {
		
		 RestAssured.baseURI= "https://run.mocky.io/v3/fb95ebba-a172-48a6-9725-43fdb94c74c0";
		 httprequest = RestAssured.given().log().all();
		 response= httprequest.when().get();
		 
		 res = RestAssured.expect();
		 res.statusCode(200);
		 
		 RestAssured.given(httprequest, res).get().then().log().all();
		
	}
	
	@Test
	public void test() {
		
		//Extract the name of player whose jersey is 20
		
		String playername = response.path("players.find{it.jerseyNumber== 20}.name");
		System.out.println(playername);
		
		//Find all name whose jersey no. greater than 20
		
		List<String> playersnames = response.path("players.findAll {it.jerseyNumber<20}.name");
		System.out.println(playersnames);
		
		
		
		//Extract values of min & max
		
		String highestjerseyno = response.path("players.max{it.jerseyNumber}.name");
		System.out.println(highestjerseyno);
		
		
		String max = response.path("players.min{it.jerseyNumber}.name");
		System.out.println(max);
		
	//  Combine find and find all
		
		Map<String,?> findpositionandcountry = response.path("players.findAll{it.position=='Keeper'}.find{it.nationality=='Argentina'}");	
		System.out.println(findpositionandcountry);
	
		
		
		//Collect and sum 
		
		  int sumOfJerseys = response.path("players.collect { it.jerseyNumber }.sum() ");
		    System.out.println(sumOfJerseys);
		    
//In this example, we use findAll() multiple times to extract the full objects (i.e. all the details) of players that match the parameters we specify. We are extracting a list of maps:
		    
		    String position = "Keeper";
		    String nationality = "Argentina";
		    ArrayList<Map<String,?>> allPlayersOfCertainPositionAndNationality = response.path("players.findAll "
		    		+ "{ it.position == '%s' }.findAll { it.nationality == '%s' }",
		            position, nationality);
		    
		    System.out.println(allPlayersOfCertainPositionAndNationality);
		
	}

}
