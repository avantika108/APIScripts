package test;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojo.GoogleMapAPIResponse;
import pojo.GoogleMapRequestAPI;
import pojo.locationapi;
import test.TestBase;

public class Serialization_D extends TestBase{

	@Test
	public void serializegson() {

		ArrayList<String> types = new ArrayList<String>();
		types.add("shoe park");
		types.add("shop");

		locationapi loc = new locationapi();
		loc.setLat(-38.383494);
		loc.setLng(33.427362);

		GoogleMapRequestAPI googleapi = new GoogleMapRequestAPI();
		googleapi.setAccuracy(50);
		googleapi.setName("Frontline house");
		googleapi.setPhone_number("(+91) 983 893 3937");
		googleapi.setAddress("29, side layout, cohen 09");
		googleapi.setWebsite("http://google.com");
		googleapi.setLanguage("French-IN");
		googleapi.setTypes(types);
		googleapi.setLocation(loc);

		Response response = RestAssured.given().contentType(ContentType.JSON).queryParam("key", "qaclick123")
				.body(googleapi).when().log().all().post("/maps/api/place/add/json");

		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		Gson gsond = new GsonBuilder().create();
		GoogleMapAPIResponse gm = gsond.fromJson(responsebody, GoogleMapAPIResponse.class);
		System.out.println(gm.status);

	}

}
