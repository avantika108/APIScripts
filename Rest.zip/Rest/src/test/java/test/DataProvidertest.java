package test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.internal.annotations.ITest;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import static org.hamcrest.Matchers.*;



public class DataProvidertest  {
	
	DataFormatter formatter = new DataFormatter();
	
	

@DataProvider(name="excelData")

public Object[][] getdata() throws IOException
{
	

	String userDirectory = System.getProperty("user.dir");
    System.out.println(userDirectory);
	FileInputStream fis = new FileInputStream(userDirectory+"/src/test/resources/excelread.xlsx");
	
	XSSFWorkbook worbook = new XSSFWorkbook(fis);
	XSSFSheet sheet = worbook.getSheetAt(1);
	

		int rowcount = sheet.getPhysicalNumberOfRows();
		int columcount =sheet.getRow(0).getLastCellNum();
		
		
	String data[][] = new String[rowcount-1][columcount];
	
	
	for(int i=1;i<rowcount;i++) {
		
		XSSFRow row = sheet.getRow(i);
		for(int j=0;j<columcount;j++) {
			
			XSSFCell cell = row.getCell(j);
			
			CellType type = cell.getCellType();
			
			if(type == CellType.NUMERIC) {
				
				data[i-1][j] = formatter.formatCellValue(cell);;
			}
			
			else if(type == CellType.STRING) {
				
				data[i-1][j] =formatter.formatCellValue(cell);
			}
		}
	}
	
	
	return data;


	
}



@Test(dataProvider = "excelData")

//public void testcasedata(String Testcasename,String Accuracy ,String Name, String Phone_number, String Address,
//									String Website , String language)
public void testcasedata(String id) 
{
	
	System.out.println(id);
	RestAssured.baseURI = "https://petstore.swagger.io/v2/pet/";

	HashMap<String,String> map = new LinkedHashMap<String,String>();
	map.put("id", id);
	map.put("name", "JohnDoe");
	map.put("status", "alive");
	
	RestAssured.baseURI= "https://petstore.swagger.io";
	
	Response response= RestAssured.given().contentType(ContentType.JSON)
			            .body(map).when().log().all()
			            .post("/v2/pet");
	
	
	
	
	String body = response.getBody().asString();

	response.then().body("status", equalTo("alive"));
	response.then().body("status", equalToIgnoringCase("ALIVE"));
	System.out.println(body);

}

			
	

}
