package test;

import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeClass;

import io.restassured.RestAssured;



public class TestBase {
	
	
	//public static PropertyReader prop;
@BeforeClass	
	public void setup() throws IOException
	{
	//	prop = PropertyReader.getInstance();
		
		RestAssured.baseURI= "https://rahulshettyacademy.com/";
		
		
	}

}
