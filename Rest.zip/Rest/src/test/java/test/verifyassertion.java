package test;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class verifyassertion {

	public static RequestSpecification httprequest;
	public static Response response;
	public static ResponseSpecification resp;

	@BeforeClass
	public void setup() {

		RestAssured.baseURI = "https://run.mocky.io/v3/b08096af-9f16-4c23-b920-e0dbcfa09237";
		httprequest = RestAssured.given().log().all();
		response = httprequest.when().get();

		resp = RestAssured.expect();
		resp.statusCode(200);

		String responsebody = response.asPrettyString();
		RestAssured.given(httprequest, resp).get().then().log().all();

	}

	@Test
	public void test1() {

		String firstteamname = response.path("teams.name[0]");
		System.out.println(firstteamname);

		// Extract the value in the listfor all teams

		ArrayList<String> allteams = response.path("teams.name");
		System.out.println(allteams);
		
		//Extract all the data for each team
		
		ArrayList<Map<String,?>> allteamsdata = response.path("teams");
		System.out.println(allteamsdata);
		
		
		//find all the data for team name Hull City FC
		
		Map<String,?> allteamdataforsingleteamname = response.path("teams.find {it.name== 'Hull City FC'}");
		System.out.println(allteamdataforsingleteamname);
		
		
		
		
		

	}

}
