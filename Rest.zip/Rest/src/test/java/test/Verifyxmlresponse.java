package test;

import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Verifyxmlresponse {
	
	RequestSpecification httprequest;
	ResponseSpecification res;
	Response response;
	
	@BeforeClass
	public void setup() {
		
		RestAssured.baseURI ="https://run.mocky.io/v3/5d70839e-7912-47d9-8175-0aac2b428950";
		
		httprequest = RestAssured.given().log().all().accept(ContentType.XML);
		response = httprequest.when().get();
		
		res = RestAssured.expect();
		res.statusCode(200);
		
		RestAssured.given(httprequest, res).get().then().log().all();
		
	}
	
	@Test
	
	public void XMLResponsevalidation(){
		
		String responsebody = response.asString();
		
		
		
		System.out.println(responsebody);
		XmlPath xml = new XmlPath(responsebody);
	    System.out.println(xml.getString("videoGames.videoGame.name[0]"));	
	    
	    
	     List<String> allnames= xml.getList("videoGames.videoGame.name");
	     System.out.println(allnames);
	     
	     String getfirstname = allnames.stream().findFirst().get();
	     System.out.println(getfirstname);
	     
	     // to get the category name 
	     
	     String category = xml.get("videoGames.videoGame[0].@category");
	     System.out.println(category);
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	  
	  
	    
	    
	  	   
	    
		
		
		
		
		
	}

}
