package ProgramsPractice;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.testng.annotations.Test;

@Test
public class Countwords {
	
	public void Countwords() {
		
		String sentence = "Hello in java world";
		String[] words = sentence.split("\\s+");
		
		HashMap<String, Integer> map = new LinkedHashMap<>();
		
		for(String word:words) {
			
			if(map.containsKey(word)) {
				
				int count = map.get(word);
				map.put(word, count+1);
			}
			
			else
				map.put(word, 1);
		}
		
		for(Entry<String, Integer> entry : map.entrySet() ) {
			
			System.out.println( entry.getKey() +"->" +entry.getValue());
		}
	}
	
	

}
