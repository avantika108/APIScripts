package ProgramsPractice;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.testng.annotations.Test;

public class number {
	
	@Test(enabled= false)
	public void fact() {
		
		int fact =1;
		int num =5;
		
		for(int i=1;i<=num;i++) {
			fact =fact*i;
		}
		
		System.out.println(fact);
	}
	@Test (enabled = false)
	public void reversenumber() {
		
		int number=65;
		StringBuffer sb = new StringBuffer(String.valueOf(number));
		StringBuffer reversenumber = sb.reverse();
		System.out.println(reversenumber);
	}
	
	@Test(enabled= false)
	
	public void pallindrome() {
		
		int number= 16361;
		
		int sum=0;
		int temp = number;
		
		while(number>0) {
			
			sum= sum *10 +number%10;
			number=number/10;
			
			
		}
		
		if(temp==sum) {
			
			System.out.println(temp+ "is pallindrome");
			
		}
		
		else
			System.out.println(temp+ "is not pallindrome");
		
		
	}
	
	
	@Test(enabled = false)
	
	public void Armstrong() {

		int a ,c=0,temp;
		int num=153;
		
		temp=num;
		while(num>0) {
			
			a=num%10;
			num=num/10;
			c=c+(a*a*a);
			
		}
		if(temp==c) {
			
			System.out.println(temp+ "is armstrong");
			
		}
		else
			System.out.println(temp+ "is not armstrong");
		
		
		
	}
	@Test(enabled=false)
	public void countdigits() {
		
		
		int number=201234;
		
		int count =0;
		while(number>0) {
			
		number=number/10;
		count++;
			
			
			
		}
		System.out.println(count);
		
	}
	
	
	@Test(enabled = false)
	public void sumofdigits() {
		
		int number=123;
		int sum=0;
		int digits;
		while(number>0) {
			digits=number%10;
			sum =sum+digits;
			number=number/10;
		}
		
		System.out.println(sum);
	}
	
	@Test(enabled=false)
	public void fibo() {
		
		int n1=0;
		int n2=1;
		System.out.println( n1+ " " +n2);
		
		int sum =0;
		int count =5;
		for(int i=2;i<=count;i++) {
			sum =n1+n2;
			System.out.println(" "+sum);
			
			n1=n2;
			n2=sum;
		}
	}
	
	@Test (enabled=false)
	
	public void ascendingorder() {
		
		List<Integer> arraylist = Arrays.asList(10,20,90,12,11,21,56,51);
		
		List<Integer> ascendingordernum = arraylist.stream().sorted().collect(Collectors.toList());
		System.out.println(ascendingordernum);
		
		List<Integer> descendinglist =arraylist.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(descendinglist);
		
		String s="he,xa,wa,re";
		String replace= s.replaceAll(",", "");
		System.out.println(replace);
		
	}
	
	@Test(enabled=false)
	public void prime() {
		
		int n=21;
		int count=0;
		
		for(int i=2;i<=n/2;i++) {
			if(n%i==0) {
				count=1;
			}
		}
		
		if(count==0) {
			
			System.out.println(n+"is prime");
		}
		
		else
			System.out.println(n+ "not prime");
	}
	
	@Test(enabled=false)
	
	public void Maxnumber() {
		
		List<Integer> list = Arrays.asList(21,1,11,12,10,8,9);
		
		int max =list.stream().max(Comparator.comparing(Integer::valueOf)).get();
		System.out.println(max);
		
		int min = list.stream().min(Comparator.comparing(Integer::valueOf)).get();
		System.out.println(min);
		
		
		List<Integer> sortedlist  = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(sortedlist);
		
		int thirdhighest = list.stream().sorted(Comparator.reverseOrder()).limit(3).skip(2).findFirst().get();
		System.out.println(thirdhighest);
		
	
	}
	
	@Test
	public void Duplicatecountinarray() {
		
		List<Integer> list = Arrays.asList(11,11,21,21,12,12,19,18,10,9);
	    Set<Integer> dups=	list.stream().filter(e->Collections.frequency(list, e)>1)
	    							
								.collect(Collectors.toSet());
	    
	//    Map<Integer, Integer> duplic = list.stream().collect(Collectors.toMap(Function.identity(),list->1 , Integer::sum));
	    
	 // 2.1 print Map for duplicate count
	 // 2. get duplicate count using Map
        Map<Integer, Integer> duplicateCountMap = list
                .stream()
                .collect(
                        Collectors.toMap(Function.identity(), company -> 1, Integer::sum)
                        );
 
 
        // 2.1 print Map for duplicate count
        System.out.println("\n2. Map with Key and its duplicate count : \n");
        duplicateCountMap.forEach(
                (key, value) -> System.out.println("Key : " + key + "\t Count : " + value)
                );
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
