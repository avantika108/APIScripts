package ProgramsPractice;

import org.testng.annotations.Test;

public class stringprog {
	
	@Test(enabled=false)
	public  void Reversestring() {
		
		String str= "Hello" ;
		StringBuffer sb = new StringBuffer(str);
		System.out.println(sb.reverse());
		
		
	}
	
	@Test(enabled=false)
	public void Reversestringother() {
		
		String str = "Avantika" ;
		int originallength = str.length();
		String reversestr="";
	
		
		for(int i =originallength-1;i>=0;i--) {
			
			reversestr=reversestr+str.charAt(i);
		}
		
		System.out.println(reversestr);
		
		
	}
	
	@Test
	public void Reverseeachword() {
		
		String inputString = "I like java programming" ;
		String[] words = inputString.split(" ");
        
        String reverseString = "";
         
        for (int i = 0; i < words.length; i++) 
        {
            String word = words[i];
             
            String reverseWord = "";
             
            for (int j = word.length()-1; j >= 0; j--) 
            {
                reverseWord = reverseWord + word.charAt(j);
            }
             
            reverseString = reverseString + reverseWord + " ";
        }
         
        System.out.println(inputString);
         
        System.out.println(reverseString);
	
	}
	

}
