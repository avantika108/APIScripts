package ProgramsPractice;

public class pllinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input="nitin" ;
		
		if (isPallindrome(input)) {
			
			System.out.println(input+ " is pallindrome");
			
		}
		else
			System.out.println(input+ " is not pallindrome");

	}

	 static boolean isPallindrome(String input) {
		 
		 int i1=0;
		 int i2=input.length()-1;
		 
		 while(i2>i1) {
			 
			 if(input.charAt(i1)!=input.charAt(i2)) {
				 return false;
				 
			 }
			 
			 i1++;
			 i2--;
		 }
		
		 return true;
		 
		 
	}

}
