package pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Complexjson {
	
	private String id;
	private String type;
	private String name;
	private double ppu;
	
	private batters batters;
	
	private List<Topping> topping = new ArrayList<Topping>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPpu() {
		return ppu;
	}

	public void setPpu(double d) {
		this.ppu = d;
	}

	public batters getBatters() {
		return batters;
	}

	public void setBatters(batters batters) {
		this.batters = batters;
	}

	public List<Topping> getTopping() {
		return topping;
	}

	public void setTopping(List<Topping> topping) {
		this.topping = topping;
	}

	public void setBatters(Map<String, Object> battermap) {
		// TODO Auto-generated method stub
		
		this.batters = batters;
		
	}
	
	
	
	

}
