package pojo;

import java.util.ArrayList;
import java.util.List;

public class batters {
	
	List<batter> batter = new ArrayList<batter>();

	public List<batter> getBatter() {
		return batter;
	}

	public void setBatter(List<batter> batter) {
		this.batter = batter;
	}
	
	
	
	

}
